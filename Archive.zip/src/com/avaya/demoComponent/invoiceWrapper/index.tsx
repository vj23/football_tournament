import * as React from 'react';
import './index.less';
export default class InvoiceWrapper extends React.Component<any, any>{
    render() {
        return (
            <div className="invoice_container__wrapper">
            </div>
        )
    }
}