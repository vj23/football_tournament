import * as React from 'react';
import * as  ReactDOM from 'react-dom';
import './index.less';
import Invoice from './invoice/index';
import InvoiceWrapper from './invoiceWrapper/index';
import InvoiceOptions from './invoiceOptions/index'
function onloadStatic1() {
  ReactDOM.render(
    <div>
      {/* <InvoiceWrapper /> */}
      <div className="outer-container">
        <div className="container">
          <Invoice />
          <InvoiceOptions />
        </div>
      </div>
    </div>,
    document.getElementById('app')
  );
}
onloadStatic1();

