import * as React from 'react';
import './index.less';
export default class Invoice extends React.Component<any, any>{
    constructor(props) {
        super(props)
        this.state = {
            invoice_gst: false
        }
    }
    componentDidMount() {
        //console.log("done with the page bhaiya ji")
    }
    render() {
        return (
            <div id="invoice" className="invoice__wrapper">
                <div className="row invoice-row invoice-branding">
                    <div className="col-8 merchant-header-col">

                        <div>
                            <h3 className="merchant-name">Amazon</h3>
                            <div>
                               GSTIN - <span className="item-default"> 06AAACB5343E1Z5</span>
                            </div>
                        </div>

                    </div>
                    <div className="col-4">
                        <a className="jio-logo" target="_blank">
                            <img src="logo_jiomobile.png" />
                        </a>
                    </div>
                </div>


                <div className="row invoice-row">
                    <div className="col-12">
                        <h3 className="">Invoice <span className="item-default">ID: inv_BOz2QFaIHUH3YM</span></h3>
                    </div>
                </div>


                <div className="row invoice-row">
                    <div className="col-12">
                        <h3 className=""><span className="item-default">Amount Due  </span>₹ 1,000.00</h3>
                    </div>
                </div>
                <div>
                    {this.state.invoice_gst ?
                        (<div><div className="row invoice-row">
                            <div className="col-6 invoice-details">
                                <div>
                                    <label>Billing to</label>
                                    <div>Viraj</div>

                                    <div>viraj1.patil@ril.com</div>

                                    <div>9967436431</div>

                                    <div className="tax-details">
                                        <span className="tax-heading">GSTIN - </span>
                                        22AAAAA0000A1Z5
                                    </div>
                                </div>
                            </div>
                            <div className="col-6 invoice-details">

                                <div>
                                    <label>Billing address</label>
                                    <div>Viraj</div>

                                    <div>viraj1.patil@ril.com</div>

                                    <div>9967436431</div>

                                    <div className="tax-details">
                                        <span className="tax-heading">GSTIN - </span>
                                        22AAAAA0000A1Z5
                                    </div>
                                </div>
                            </div>
                        </div>
                            <div className="row invoice-row">
                            <div className="col-6 invoice-details">

                                    <div>
                                        <div>
                                            <label>Shiiping address</label>
                                            <div>Viraj</div>

                                            <div>viraj1.patil@ril.com</div>

                                            <div>9967436431</div>

                                            <div className="tax-details">
                                                <span className="tax-heading">GSTIN - </span>
                                                22AAAAA0000A1Z5
                                            </div>
                                        </div>

                                        <div className="place-supply">
                                            <label>Place of supply</label>
                                            <div>Karnataka</div>

                                        </div>

                                    </div>
                                </div>
                                <div className="col-6 invoice-details">
                                    <div>
                                        <div className="invoice-date">
                                            <label>ISSUE DATE</label>
                                            <div>
                                                19 Nov 2018
                                        </div>
                                        </div>

                                      <div className="invoice-date">
                                            <label>Expiry DATE</label>
                                            <div>
                                                19 Nov 2018
                                        </div>
                                        </div> 
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                        )
                        : (
                            <div className="row invoice-row">
                                <div className="col-6 invoice-details">
                                    <div>
                                        <label>BILLING TO</label>
                                        <div>Viraj</div>

                                        <div>viraj1.patil@ril.com</div>

                                        <div>9967436431</div>

                                        <div className="tax-details">
                                            <span className="tax-heading">GSTIN - </span>
                                            22AAAAA0000A1Z5
                            </div>
                                    </div>
                                </div>
                                <div className="col-6 invoice-details">

                                    <div className="invoice-date">
                                        <label>ISSUE DATE</label>
                                        <div>
                                            19 Nov 2018
                            </div>
                                    </div>
                                </div>
                            </div>
                        )}
                </div>
                <div className="row">

                    <div className="lineitems-container">
                        <div className="table-responsive">
                            <table className="table inv__itemtable">
                                <thead>
                                    <tr>
                                        <th className="lineItem__item">DESCRIPTION</th>
                                        <th className="lineItem__amount text-right">UNIT PRICE</th>
                                        <th className="lineItem__qty text-right">QTY</th>
                                        <th className="lineItem__total text-right">AMOUNT</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td className="lineItem__item">
                                            <div>
                                                <span className="item-name">2</span>
                                            </div>
                                            <div className="item-desc">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</div>
                                        </td>
                                        <td className="lineItem__amount rate text-right">
                                            <span className="amount">₹ 100.00</span>
                                            <div className="item__taxes-names">
                                                <div>
                                                    CGST@9%
                                            </div>
                                                <div>
                                                    SGST@9%
                                            </div>
                                            </div>
                                        </td>
                                        <td className="lineItem__qty qty text-right">1</td>
                                        <td className="lineItem__total amount text-right">
                                            <span className="amount">₹ 100.00</span>
                                            <div className="item__taxes-amounts">
                                                <div>
                                                    ₹ 100.00
                                            </div>
                                                <div>
                                                    ₹ 100.00
                                            </div>
                                            </div>
                                        </td>
                                    </tr>

                                </tbody>

                            </table>

                        </div>

                    </div>

                </div>

                {/* <div className="inv-comments row invoice-row">
                    <div className="col-12">
                        Customer notes Line 1
                        Customer notes Line 2
                        Customer notes Line 3
                    </div>
                </div> */}
                {/*   <div className="invoice__head">
                    <div style={{ fontSize: "30px" }}>Amazon.com</div>


                </div>

                <div className="row invoice-row">
                    <div className="col-8">

                    </div>
                    <div className="col-4">

                    </div>


                </div>
 */}
                {/* <div className="invoice__billing">
                    <div className="invoice__billing_head">
                        <div>
                            <span>Invoice </span> Receipt 12345
                        </div>
                    </div>
                    <div className="invoice__billing_amount">
                        <div>
                            <span>Amount Due</span> &#8377; 100000
                        </div>
                    </div>
                    <div className="invoice__billing_address">
                        <div>
                            <div className="invoice__billing_address_item">
                                <div>
                                    Billing to
                                </div>
                                <div>
                                    dhimanAnkit@ril.com
                                </div>
                            </div>
                            <div className="invoice__billing_address_item">
                                <div>
                                    Issue date
                            </div>
                                <div>
                                    19 set 2018
                            </div>
                            </div>
                            <div className="invoice__billing_address_item">
                                <div>
                                    Expiry date
                            </div>
                                <div>
                                    20 sept 2018
                            </div>
                            </div>
                        </div>

                        <div>
                            <div className="invoice__billing_address_item">
                                <div>
                                    Billing address
                                </div>
                                <div>
                                    Reliance Jio 5th foor
                            </div>
                            </div>
                            <div className="invoice__billing_address_item">
                                <div>
                                    Place of Supply
                            </div>
                                <div>
                                    Maharashtra
                            </div>
                            </div>

                        </div>
                    </div>
                </div>
                <div>
                    <table>
                        <thead>
                            <tr className="test">
                                <th>Description</th>
                                <th>Unit Price</th>
                                <th>QTY</th>
                                <th>Amount</th>
                            </tr>
                        </thead>

                        <tr>
                            <td>Versace</td>
                            <td>50</td>
                            <td>50</td>
                            <td>2500</td>
                        </tr>
                        <tr>
                            <td></td>
                            <td></td>
                            <td>Tax</td>
                            <td>18</td>
                        </tr>
                        <tr>
                            <td></td>
                            <td></td>
                            <td>Total Amount</td>
                            <td>&#8377; 2000000</td>
                        </tr>

                    </table>

                </div>
                <div className="invoice__footer">
                    <div>
                        Terms and Conditions**
                </div>

                </div> */}
            </div>
        )
    }
}