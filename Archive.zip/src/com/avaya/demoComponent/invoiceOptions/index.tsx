import * as React from 'react';
import './index.less';
import * as html2canvas from 'html2canvas';
import * as jsPDF from 'jspdf';

export default class InvoiceOptions extends React.Component<any, any>{
    printDocument() {
        const input = document.getElementById('invoice');
        html2canvas(input)
            .then((canvas) => {
                const imgData = canvas.toDataURL('image/png');
                const pdf = new jsPDF();
                pdf.addImage(imgData, 'JPEG', 0, 0);
                pdf.save("sample.pdf");

            })
    }
    render() {
        return (
                <div className="cta-toolbar">
                    <button className="invoice-pay btn btn-primary">
                        Proceed to Pay
                    <span className="amount"> ₹ 1,000.00</span>
                    </button>

                    <div className="btn-group-vertical">
                        <a className="btn btn-default" onClick={() => { this.printDocument() }}>
                            <span>Download Invoice</span>
                        </a>

                        <a className="btn btn-default" href="/v1/invoices/inv_BOz2QFaIHUH3YM/pdf?key_id=rzp_test_DiCrCVnqP9LS63" target="_blank">
                            <span>Print Invoice</span>
                        </a>
                    </div>
                </div>
            
        )
    }
}