interface Window {
    appLocale:any
}

declare var window: Window;