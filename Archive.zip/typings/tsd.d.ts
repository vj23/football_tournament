
interface System {
    import (request: string): Promise<any>
}

declare var System: System;