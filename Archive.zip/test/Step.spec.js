import React from 'react';
import Step from '../src/com/avaya/components/wizard/Step';
import { renderToStaticMarkup } from 'react-dom/server';
 let componentClass=React.createClass({displayName:'component',
         render:function(){
             return React.createElement('h4',null,'Dynamic Component Rendering');
         }
    });

describe('<Step>', function () {
    it('it should exist', function () {

         const wrapper = mount(<Step lastStep='false' component={componentClass} />);
       
       
        
    })
    it('it should contain initial state', function () {

       const wrapper = mount(<Step lastStep='false' component={componentClass} />);
       
       
        expect(wrapper.state()).to.deep.equal({ advanceDisabled: false, retreatDisabled: false });
        
    })

     it('it should not have next button based on  if last step is not provided', function () {

        const wrapper = mount(<Step  component={componentClass} />);
       
        if(wrapper.find('#advanceStep')===undefined);
        expect(wrapper.find('#advanceStep')).to.be.not.defined;
       

    })

   
     it('it should have Next button based on  last step provided', function () {

         const wrapper = mount(<Step lastStep='false' component={componentClass} />);
        wrapper.find('#advanceStep').simulate('click');
       

    })
    it('it should have Back  button based on  last step provided', function () {

        const wrapper = mount(<Step lastStep='false' component={componentClass} />);
        wrapper.find('#advanceStep').simulate('click');
       

    })
     it('it should have Component based on  Component is provided', function () {
        
        const wrapper = mount(<Step lastStep='false' component={componentClass} />);
        wrapper.find('#backStep').simulate('click');
       

    })



});
