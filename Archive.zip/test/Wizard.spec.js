import React from 'react';
import Wizard from '../src/com/avaya/components/wizard/Wizard';
import { renderToStaticMarkup } from 'react-dom/server';
 let componentClass=React.createClass({displayName:'component',
         render:function(){
             return React.createElement('h4',null,'Dynamic Component Rendering');
         }
    });

    let stepRaw1={
        name:'Host1',
        component:componentClass,
        onSubmit:function(){},

    }
    let stepRaw2={
        name:'Host2',
        component:componentClass,
        onSubmit:function(){},

    }
    var stepWrapper=React.createClass({
        render : function(){
            return( <Step lastStep={false} component={componentClass}/>);
        }
    });

describe('<Wizard>', function () {
    it('it should exist', function () {

         const wrapper = mount(<Wizard/>);
       
       
        
    })

   
    it('Steps dont exists', function () {

         const wrapper = mount(<Wizard/>);
       
        expect(wrapper.props.steps).to.be.not.defined;
       
        
    })

     it('Steps and left Nav for steps exists', function () {
let steps=[stepRaw1,stepRaw2];
         const wrapper = mount(<Wizard steps={steps}/>);
        expect(wrapper.props().steps).to.be.defined;
       
        expect(wrapper.find('.wizard-navigation')).to.have.length(2);
         //expect().to.be.not.defined;
       
        
    })

     it('Component Step for steps exists', function () {
        let steps=[stepRaw1,stepRaw2];
         const wrapper = mount(<Wizard steps={steps}/>);
      
       
        expect(wrapper.find('#Host1')).to.have.length(1);
         wrapper.find('#advanceStep').simulate('click');
         //expect().to.be.not.defined;
       
        
    })
   



});
