var path = require('path');
var express = require('express');
var webpack = require('webpack');
var config = require('./webpack.config');
var app = express();
var compiler = webpack(config);
var bodyParser = require('body-parser');
var tableJson = require('./data1.json');
var server = require('http').createServer();
var WebSocketServer = require('ws').Server;
//var wss = new WebSocketServer({ server: server });

app.use(require('webpack-dev-middleware')(compiler, {
  noInfo: true,
  publicPath: config.output.publicPath
})); 

app.use(express.static(__dirname));
app.use('/en', express.static(__dirname+"/locale"));
app.use('/de', express.static(__dirname+"/locale"));
var jsonParser = bodyParser.json();
 
// create application/x-www-form-urlencoded parser 
var urlencodedParser = bodyParser.urlencoded({ extended: false });
app.get('/tableDemo/getData',urlencodedParser , function (req, res) {
  console.log("get table data");
  setTimeout(
     function(){res.end(JSON.stringify(tableJson));},10000) 

    
});

app.get('/tableDemo/dataSource',urlencodedParser , function (req, res) {
        let datanew = {};
        let temp = [];
        console.log(req.query.pageSize)
        for (let i = 1; i < req.query.pageSize; i++) {
                temp.push({
                    key: 'cc:cc' + i,
                    name: `John cook ${i}`,
                    gender: "Male",
                    address: `India. ${i}`,
                    address1: `India. ${i}`,
                    address2: `India. ${i}`,
                    address3: `India. ${i}`,
                    address4: `India. ${i}`,
                    description: 'I am '+i,
                    hidden: false,
                    img:'/alert.png'
                });
            }
        datanew['list'] = temp;
        res.end(JSON.stringify(datanew))

        
    
});

app.get('/tableDemo/getImage',urlencodedParser , function (req, res) {
  console.log(JSON.stringify("sending image file"));
  res.sendFile(path.join(__dirname,'/warning.png'));
    
});

app.get('*', function(req, res) {
   console.log("inside serving request");
 
  res.sendFile(path.join(__dirname, '/index.html'));
});




app.listen(9400, 'localhost', function(err) {
  if (err) {
    console.log("printing error::::::::::");
    console.log(err);
    return;
  }

  console.log('Listening at http://localhost:9400');
});



/* wss.on('connection', function (ws) {
  try {
    console.log("pritning...........")
    let progress=20
    setInterval(()=>{
      progress=progress+5
      ws.send(JSON.stringify({progress:progress}))
    },2000)
    
  }
  catch (error) {
    console.log(error)
    
  }

  ws.on('error',function(){
    console.log("catching the error on the websocket");
  })
});

server.on('request', app);
  server.listen(9500,'135.123.149.27',function () { // server listens on port 8080
    console.log('Listening on http://localhost:8080');
  }); */