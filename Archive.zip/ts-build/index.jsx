"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const react_1 = require("react");
const react_dom_1 = require("react-dom");
const react_redux_1 = require("react-redux");
const redux_1 = require("redux");
const redux_thunk_1 = require("redux-thunk");
const redux_logger_1 = require("redux-logger");
var LoginReducer = require("./demoComponent/wizard/reducers/LoginReducer");
const PageLayout_1 = require("./demoComponent/PageLayout");
require("babel-polyfill");
const middleware = [redux_thunk_1.default];
if (process.env.NODE_ENV !== 'production') {
    middleware.push(redux_logger_1.default());
}
var rootReducer = redux_1.combineReducers({
    loginForm: LoginReducer
});
const store = redux_1.createStore(rootReducer, redux_1.applyMiddleware(...middleware));
react_dom_1.default.render(<react_redux_1.Provider store={store}>
  <PageLayout_1.default />
  </react_redux_1.Provider>, document.getElementById('app'));
//# sourceMappingURL=index.jsx.map