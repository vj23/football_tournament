"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class LoginModel {
    setUserName(username) {
        this.username = username;
    }
    getUserName() {
        return this.username;
    }
    setPassword(password) {
        this.password = password;
    }
    getPassword() {
        return this.password;
    }
}
exports.default = LoginModel;
//# sourceMappingURL=LoginModel.jsx.map