"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const react_1 = require("react");
const react_router_1 = require("react-router");
const react_router_2 = require("react-router");
const AvayaTableContainer_1 = require("../avayaTable/container/AvayaTableContainer");
require("./css/demoStyle.css");
const Main_1 = require("./Main");
const Wizard_1 = require("../wizard/Wizard");
const react_bootstrap_1 = require("react-bootstrap");
var LoginActionCreator = require("./wizard/actions/LoginActionCreator");
const react_validate_1 = require("react-validate");
const validator_1 = require("validator");
function validateLength(value) {
    return validator_1.default.isLength(value, { min: 6 });
}
class SimpleWithErrors extends react_1.default.Component {
    formAction(event) {
        event.preventDefault();
        this.props.addToData(this.state);
        alert(`Mock submit form`);
    }
    constructor(props) {
        super(props);
        this.state = {
            email: (this.props.data.email !== undefined) ? this.props.data.email : '',
            password: (this.props.data.password !== undefined) ? this.props.data.password : ''
        };
        this.handleInputChange = this.handleInputChange.bind(this);
        this.formAction = this.formAction.bind(this);
    }
    handleInputChange(event) {
        const target = event.target;
        const value = target.type === 'checkbox' ? target.checked : target.value;
        const name = target.name;
        this.setState({
            [name]: value
        });
    }
    render() {
        const validateEmail = validator_1.default.isEmail;
        var loginProps = this.props.loginForm;
        this.state = {
            email: (loginProps.username !== undefined) ? loginProps.username : '',
            password: (loginProps.password !== undefined) ? loginProps.password : ''
        };
        let loginModel = new loginModel();
        loginModel.setUserName(this.state.email);
        loginModel.setPassword(this.state.password);
        return (<form onSubmit={this.props.login(loginModel)}>
        <react_validate_1.ValidateGroup>
          <h3>Email</h3>
          <react_validate_1.Validate validators={[validateEmail]}>
            <react_bootstrap_1.FormControl type="text" name="email" value={this.state.email} onChange={this.handleInputChange} placeholder="Enter text"/>

            <react_validate_1.ErrorMessage>Not a valid email</react_validate_1.ErrorMessage>
          </react_validate_1.Validate>
          <h3>Password</h3>
          <react_validate_1.Validate validators={[validateLength]}>
            <react_validate_1.ErrorMessage>Password too short. Use at least 6 characters</react_validate_1.ErrorMessage>
            <react_bootstrap_1.FormControl type="password" name="password" value={this.state.password} onChange={this.handleInputChange}/>
          </react_validate_1.Validate>
          <button type="submit">Submit</button>
        </react_validate_1.ValidateGroup>
      </form>);
    }
}
SimpleWithErrors.propTypes = {
    loginForm: ptypes.shape({
        username: PropTypes.string.isRequired,
        password: PropTypes.string.isRequired
    }).isRequired,
    login: ptypes.func.isRequired,
};
var mapStateToProps = function (state) {
    // This component will have access to `state.battlefield` through `this.props.battle`
    return { loginForm: state.loginForm };
};
var mapDispatchToProps = function (dispatch) {
    return {
        login: function (loginform) { dispatch(LoginActionCreator.login(loginform)); },
    };
};
let componentClass1 = react_1.default.createClass({
    displayName: 'component',
    onNameChange: function (e) {
        this.props.addToData({ name: e.target.value });
    },
    render: function () {
        return <input type="text" name="firstname" onChange={this.onNameChange.bind(this)}/>;
    }
});
let componentClass2 = react_1.default.createClass({
    displayName: 'component',
    onNameChange: function (e) {
        this.props.name = e.target.value;
    },
    render: function () {
        return <div>{this.props.data.email}<br />{this.props.data.password}</div>;
    }
});
var stepWrapper = react_1.default.createClass({
    render: function () {
        return (<Step lastStep={false} component={componentClass1}/>);
    }
});
let stepRaw1 = {
    name: 'LoginPage',
    component: SimpleWithErrors,
    onSubmit: function () { },
};
let stepRaw2 = {
    name: 'SuccessPage',
    component: componentClass2,
    onSubmit: function () { },
};
let steps = [stepRaw1, stepRaw2];
var wizardWrapper = react_1.default.createClass({
    render: function () {
        return (<Wizard_1.default steps={steps}/>);
    }
});
class PageLayout extends react_1.default.Component {
    render() {
        return (<div>
        <div>
          <react_router_1.Router history={react_router_1.browserHistory}>
            <react_router_2.Route path="/" component={Main_1.default}>
              <react_router_2.Route path="/table" component={AvayaTableContainer_1.default}/>
              <react_router_2.Route path="/step" component={wizardWrapper}/>
            </react_router_2.Route>
          </react_router_1.Router>
        </div>
      </div>);
    }
}
exports.default = PageLayout;
//# sourceMappingURL=PageLayout.jsx.map