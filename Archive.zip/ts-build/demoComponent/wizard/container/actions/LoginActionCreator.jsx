"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const constants = require("../constants/ActionConstant");
const LoginService_1 = require("../services/LoginService");
require("rxjs/add/operator/map");
class LoginActionCreators {
    requestLogin(loginForm) {
        return {
            type: constants.REQUESTLOGIN,
            payload: loginForm
        };
    }
    requestLoginSuccess(loginForm) {
        return {
            type: constants.SUCCESS,
            payload: loginForm
        };
    }
    static login(loginForm) {
        return function (dispatch) {
            dispatch(this.requestLogin(loginForm));
            return LoginService_1.default.authorizeLogin(loginForm)
                .map(value => {
                if (value) {
                    dispatch(this.requestLoginSuccess(loginForm));
                }
            });
        };
    }
}
exports.default = LoginActionCreators;
//# sourceMappingURL=LoginActionCreator.jsx.map