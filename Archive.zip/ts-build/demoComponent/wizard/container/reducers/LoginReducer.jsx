"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ActionConstant_1 = require("../constants/ActionConstant");
exports.LoginReduce = (state = [], action) => {
    let newState = Object.assign({}, state);
    console.log(newState);
    switch (action.type) {
        case ActionConstant_1.default.SUCCESS:
            return newState;
    }
};
//# sourceMappingURL=LoginReducer.jsx.map