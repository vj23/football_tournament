"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const Observable_1 = require("rxjs/Observable");
class LoginService {
    constructor() {
    }
    static authorizeLogin(logingForm) {
        let obs = Observable_1.Observable.create((observer) => {
            observer.next(true);
        });
        return obs;
    }
}
exports.default = LoginService;
//# sourceMappingURL=LoginService.jsx.map