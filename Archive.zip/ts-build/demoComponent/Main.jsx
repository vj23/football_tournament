"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const react_1 = require("react");
const react_router_1 = require("react-router");
require("./css/demoStyle.css");
class Main extends react_1.Component {
    render() {
        return (<div>
               <div>
                    <div id="mySidenav" className="sidenav">                       
                        <react_router_1.Link to="/table">AvayaTable</react_router_1.Link>
                        <react_router_1.Link to="/step">Wizard</react_router_1.Link>
                        <react_router_1.Link to="/Wizard">BreadCrumbs</react_router_1.Link>
                                               
                    </div>
               </div>
                <div className="actualBody">   
                    <div style={{ height: '70%' }}>            
                        {this.props.children}
                    </div>
                </div>
            </div>);
    }
}
exports.default = Main;
//# sourceMappingURL=Main.jsx.map