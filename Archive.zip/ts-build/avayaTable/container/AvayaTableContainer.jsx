"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const react_1 = require("react");
//import * as productActions from '../../actions/productActions';
const AvayaTable_1 = require("../component/AvayaTable");
class AvayaTableContainer extends react_1.default.Component {
    constructor(props, context) {
        super(props, context);
        this.state = {
            activePage: 1
        };
        //this.onNavigatePage = this.onNavigatePage.bind(this);
    }
    onNavigatePage(page, sizePerPage) {
        this.props.actions.loadAllProducts(page);
        this.setState({ activePage: page });
    }
    render() {
        var products = [{
                id: 1,
                name: "Product1",
                price: 120
            }, {
                id: 2,
                name: "Product2",
                price: 80
            },
            {
                id: 3,
                name: "Product2",
                price: 80
            },
            {
                id: 4,
                name: "Product2",
                price: 80
            },
            {
                id: 5,
                name: "Product2",
                price: 80
            }];
        return (<AvayaTable_1.default tableData={products} activePage={this.state.activePage} pagination={true} hideSizePerPage={false}/>);
    }
}
exports.default = AvayaTableContainer;
/*AvayaTableContainer.propTypes = {
  products: PropTypes.object.isRequired,
  actions: PropTypes.object.isRequired
};

function mapStateToProps(state, ownProps) {
  return {
    products: state.products
  };
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(productActions, dispatch)
  };
}*/
//export default connect(mapStateToProps, mapDispatchToProps)(AvayaTableContainer);
//# sourceMappingURL=AvayaTableContainer.jsx.map