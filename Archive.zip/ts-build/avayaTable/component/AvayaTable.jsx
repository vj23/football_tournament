"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const react_1 = require("react");
const react_bootstrap_table_1 = require("react-bootstrap-table");
require("react-bootstrap-table/dist/react-bootstrap-table-all.min.css");
require("bootstrap/dist/css/bootstrap.min.css");
class AvayaTable extends react_1.default.Component {
    constructor() {
        super();
    }
    render() {
        const options = {
            page: 1,
            sizePerPageList: this.props.sizePerPageList,
            sizePerPage: this.props.sizePerPage,
            hideSizePerPage: this.props.hideSizePerPage
        };
        return (<react_bootstrap_table_1.BootstrapTable data={this.props.tableData} pagination={this.props.pagination} options={options}>
             
                <react_bootstrap_table_1.TableHeaderColumn dataField='id' isKey={true}>Product ID</react_bootstrap_table_1.TableHeaderColumn>
                <react_bootstrap_table_1.TableHeaderColumn dataField='name'>Product Name</react_bootstrap_table_1.TableHeaderColumn>
                <react_bootstrap_table_1.TableHeaderColumn dataField='price'>Product Price</react_bootstrap_table_1.TableHeaderColumn>
            </react_bootstrap_table_1.BootstrapTable>);
    }
}
exports.default = AvayaTable;
AvayaTable.propTypes = {
    tableData: react_1.default.PropTypes.array.isRequired,
    activePage: react_1.default.PropTypes.number.isRequired,
    // onNavigatePage: PropTypes.func.isRequired,
    hideSizePerPage: react_1.default.PropTypes.bool,
    sizePerPageList: react_1.default.PropTypes.array,
    sizePerPage: react_1.default.PropTypes.number,
    pagination: react_1.default.PropTypes.bool
};
AvayaTable.defaultProps = {
    sizePerPage: 10,
    pagination: false,
    hideSizePerPage: true
};
//# sourceMappingURL=AvayaTable.jsx.map