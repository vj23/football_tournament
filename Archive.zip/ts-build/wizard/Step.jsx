"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const react_1 = require("react");
const react_bootstrap_1 = require("react-bootstrap");
const react_bootstrap_2 = require("react-bootstrap");
class Step extends react_1.default.Component {
    constructor(props) {
        super(props);
        this.state = {
            advanceDisabled: false,
            retreatDisabled: false
        };
    }
    next() {
        this.props.onAdvance();
    }
    back() {
        this.props.onBack();
    }
    render() {
        let AdvanceButton, BackButton;
        AdvanceButton = react_1.default.createElement(react_bootstrap_1.Button, {
            key: 'advanceStep',
            id: 'advanceStep',
            bsStyle: 'primary',
            bsSize: 'small',
            onClick: this.next.bind(this),
            disabled: this.props.lastStep
        }, 'Next');
        BackButton = react_1.default.createElement(react_bootstrap_1.Button, {
            key: 'backStep',
            id: 'backStep',
            bsSize: 'small',
            onClick: this.back.bind(this),
            disabled: this.props.firstStep
        }, 'Back');
        let ComponentClass = this.props.component;
        return (<div className='step' id={this.props.id}>
       
                <ComponentClass {...this.props}/>
                <react_bootstrap_2.ButtonToolbar>
                    {AdvanceButton}
                    {BackButton}
                </react_bootstrap_2.ButtonToolbar>
            </div>);
    }
}
exports.default = Step;
//# sourceMappingURL=Step.jsx.map