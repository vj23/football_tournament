"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const react_1 = require("react");
const react_bootstrap_1 = require("react-bootstrap");
const react_bootstrap_2 = require("react-bootstrap");
const Step_1 = require("./Step");
class Wizard extends react_1.default.Component {
    constructor(props) {
        super(props);
        this.state = {
            currentStep: 0,
            data: this.props
        };
    }
    addData(obj) {
        self = this;
        let mergedObj = Object.assign({}, self.props, obj);
        this.setState({
            data: mergedObj
        });
    }
    render() {
        let self = this;
        let items = null, Component = null;
        if (self.props.steps !== undefined) {
            items = self.props.steps.map(function (step, id) {
                if (self.props.steps !== undefined) {
                    return (<react_bootstrap_1.ListGroupItem key={'nav' + id} className="wizard-navigation" active={id === self.state.currentStep}>{step.name}</react_bootstrap_1.ListGroupItem>);
                }
            });
            let step = this.props.steps[self.state.currentStep];
            Component = react_1.default.createElement(Step_1.default, {
                component: step.component,
                lastStep: self.state.currentStep === self.props.steps.length - 1,
                firstStep: self.state.currentStep === 0,
                key: step.name,
                id: step.name,
                className: "stepId",
                data: self.state.data,
                addToData: self.addData.bind(self),
                onAdvance: function () {
                    self.setState((prevState, props) => {
                        return { currentStep: prevState.currentStep + 1 };
                    });
                },
                onBack: function () {
                    self.setState((prevState, props) => {
                        return { currentStep: prevState.currentStep - 1 };
                    });
                }
            });
        }
        return (<div className="wizard">
                <div className="wizard-nav col-xs-2">
                    <react_bootstrap_2.ListGroup>
                        {items}
                    </react_bootstrap_2.ListGroup>
                </div>
                <div className="wizard-content col-xs-4">
                    {Component}
                </div>
            </div>);
    }
}
exports.default = Wizard;
//# sourceMappingURL=Wizard.jsx.map